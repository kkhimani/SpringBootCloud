package com.ge.supplierconn.exception;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.supplierconn.security.dto.UserDetailsDto;

@ControllerAdvice
public class ExceptionHandlerController {

	private static final Logger logger = LoggerFactory.getLogger(ExceptionHandlerController.class);
	
	@ExceptionHandler(MultipartException.class)
	public void handleSizeExceededException(HttpServletRequest request, MultipartException ex) throws MultipartException{
	    //code
		logger.info("Exception in MultipartException", ex.getMessage());
		request = setRequestAttribute("File size is too large.", ex.getMessage(),
				HttpStatus.PAYLOAD_TOO_LARGE, request);
		throw ex;
	}
	
	@ExceptionHandler(FileSizeTooLargeException.class)
	public void handleSizeExceededException(HttpServletRequest request, FileSizeTooLargeException ex) throws FileSizeTooLargeException{
	    //code
		logger.info("Exception in MultipartException", ex.getMessage());
		request = setRequestAttribute("File size is too large", ex.getMessage(),
				HttpStatus.BAD_REQUEST, request);
		throw ex;
	}
	
	
	@ExceptionHandler(NoHandlerFoundException.class)
	public void handleException(NoHandlerFoundException ex, HttpServletRequest request) throws NoHandlerFoundException {

		logger.info("Exception in NoHandlerFoundException", ex.getMessage());
		request = setRequestAttribute("The URL you have reached is not in service at this time (404).", ex.getMessage(),
				HttpStatus.NOT_FOUND, request);
		throw ex;
	}

	@ExceptionHandler(EurekaDownException.class)
	@ResponseBody
	public void handleException(EurekaDownException ex, HttpServletRequest request) throws EurekaDownException {
		logger.error("Exception", ex);
		request = setRequestAttribute("Service Registry is down", ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR,
				request);
		throw ex;
	}

	@ExceptionHandler(JsonParseException.class)
	@ResponseBody
	public void handleException(JsonParseException ex, HttpServletRequest request) throws JsonParseException {
		logger.error("Exception", ex);
		request = setRequestAttribute(UserDetailsDto.GUEST_USER.toString(), ex.getMessage(), HttpStatus.CONTINUE,
				request);
		throw ex;
	}

	@ExceptionHandler(JsonMappingException.class)
	@ResponseBody
	public void handleException(JsonMappingException ex, HttpServletRequest request) throws JsonMappingException {
		logger.error("Exception", ex);

		request = setRequestAttribute(UserDetailsDto.GUEST_USER.toString(), ex.getMessage(), HttpStatus.CONTINUE,
				request);
		throw ex;
	}

	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	@ResponseBody
	public void handleException(HttpMediaTypeNotSupportedException ex, HttpServletRequest request)
			throws HttpMediaTypeNotSupportedException {
		logger.error("Exception", ex);
		request = setRequestAttribute("Please check the method type that used", ex.getMessage(), HttpStatus.BAD_REQUEST,
				request);
		throw ex;
	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	@ResponseBody
	public void handleException(HttpRequestMethodNotSupportedException ex, HttpServletRequest request)
			throws HttpRequestMethodNotSupportedException {
		logger.error("Exception", ex);
		request = setRequestAttribute("Please check the method that used", ex.getMessage(), HttpStatus.BAD_REQUEST,
				request);
		throw ex;
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	@ResponseBody
	public void handleException(HttpMessageNotReadableException ex, HttpServletRequest request)
			throws HttpMessageNotReadableException {
		logger.error("Exception", ex);
		request = setRequestAttribute("You are passing invalid data", ex.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY,
				request);
		throw ex;
	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	public void handleException(Exception ex, HttpServletRequest request) throws Exception {
		logger.error("Exception", ex);
		request = setRequestAttribute("Internal Server Error", ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR,
				request);
		throw ex;
	}

	@ExceptionHandler(AmazonClientException.class)
	@ResponseBody
	public void handleException(AmazonClientException ex, HttpServletRequest request) throws AmazonClientException {
		logger.error("Exception", ex);
		logger.info("Caught an AmazonClientException, which means" + " the client encountered "
				+ "an internal error while trying to " + "communicate with S3, "
				+ "such as not being able to access the network.");
		logger.info("Error Message: " + ex.getMessage());
		// message += fileName + ":error:" + ace.getMessage() + "\r\n";
		request = setRequestAttribute("AmazonClientException Error", ex.getMessage(), HttpStatus.BAD_REQUEST, request);
		throw ex;
	}

	@ExceptionHandler(AmazonServiceException.class)
	@ResponseBody
	public void handleException(AmazonServiceException ase, HttpServletRequest request) throws AmazonServiceException {
		logger.error("Exception", ase);
		logger.info("Caught an AmazonServiceException, which" + " means your request made it "
				+ "to Amazon S3, but was rejected with an error request" + " for some reason.");
		logger.info("Error Message:    " + ase.getMessage());
		logger.info("HTTP Status Code: " + ase.getStatusCode());
		logger.info("AWS Error Code:   " + ase.getErrorCode());
		logger.info("Error Type:       " + ase.getErrorType());
		logger.info("Request ID:       " + ase.getRequestId());
		// message += fileName + ":error:" + ase.getMessage() + "\r\n";

		request = setRequestAttribute("AmazonServiceException Error", ase.getMessage(), HttpStatus.BAD_REQUEST,
				request);
		throw ase;
	}

	@ExceptionHandler(IOException.class)
	@ResponseBody
	public void handleException(IOException ex, HttpServletRequest request) throws IOException {
		logger.error("Exception", ex);
		request = setRequestAttribute("IOException Error", ex.getMessage(), HttpStatus.BAD_REQUEST, request);
		throw ex;
	}

	@ExceptionHandler(ServletException.class)
	@ResponseBody
	public void handleException(ServletException ex, HttpServletRequest request) throws ServletException {
		logger.error("Exception", ex);
		request = setRequestAttribute("ServletException Error", ex.getMessage(), HttpStatus.BAD_REQUEST, request);
		throw ex;
	}

	@ExceptionHandler(JSONException.class)
	@ResponseBody
	public void handleException(JSONException ex, HttpServletRequest request) throws JSONException {
		logger.error("Exception", ex);
		request = setRequestAttribute("JSONException Error", ex.getMessage(), HttpStatus.BAD_REQUEST, request);
		throw ex;
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseBody
	public void handleException(MethodArgumentNotValidException ex, HttpServletRequest request)
			throws MethodArgumentNotValidException {

		BindingResult result = ex.getBindingResult();
		String message = "Missing required fields:";
		if (result != null && result.getFieldErrors() != null) {
			for (FieldError error : result.getFieldErrors()) {
				message.concat(" ").concat(error.getField());
			}
		}
		request = setRequestAttribute(message, ex.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY, request);
		throw ex;
	}
	@ExceptionHandler(IntrusionException.class)
	public ResponseEntity<Object> handleException(IntrusionException ex, HttpServletRequest request) throws IntrusionException
	{
	    logger.info("Exception in IntrusionException", ex.getMessage());
	    request = setRequestAttribute("Security attack caught", ex.getMessage(), HttpStatus.BAD_REQUEST,request);
	    throw ex;
	}
	@ExceptionHandler(ValidationException.class)
	public ResponseEntity<Object> handleException(ValidationException ex, HttpServletRequest request) throws ValidationException
	{
	    logger.info("Exception in ValidationException", ex.getMessage());
	    request = setRequestAttribute("Invalid data passed", ex.getMessage(), HttpStatus.BAD_REQUEST,request);
        throw ex;
	}
	public HttpServletRequest setRequestAttribute(String uiMessage, String devMessage, HttpStatus status,
			HttpServletRequest request) {
		request.setAttribute("uiMessage", uiMessage);
		request.setAttribute("devMessage", devMessage);
		request.setAttribute("status", status.toString());
		return request;
	}
}
