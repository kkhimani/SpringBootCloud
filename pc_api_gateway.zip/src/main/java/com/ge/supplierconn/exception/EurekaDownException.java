package com.ge.supplierconn.exception;

public class EurekaDownException extends Exception {
	 
	public EurekaDownException()	{	}

	public EurekaDownException(String message) {
		super(message);
	}

	public EurekaDownException(Throwable cause)
	{
		super(cause);
	}

	public EurekaDownException(String message, Throwable cause)
	{
		super(message, cause);
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	
}
