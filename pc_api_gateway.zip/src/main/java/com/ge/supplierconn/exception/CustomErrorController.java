package com.ge.supplierconn.exception;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Validator;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@Component
@PropertySource("classpath:application.properties")
public class CustomErrorController implements ErrorController {

	private static final Logger logger = LoggerFactory.getLogger(CustomErrorController.class);

	@Value("${sc.errorPageURL}")
	private String errorPageURL;
	
	private Validator validator = ESAPI.validator();

	private static CustomErrorController appErrorController;

	/**
	 * Error Attributes in the Application
	 */
	@Autowired
	private ErrorAttributes errorAttributes;

	private final static String ERROR_PATH = "/error";

	/**
	 * Controller for the Error Controller
	 * 
	 * @param errorAttributes
	 * @return
	 */

	public CustomErrorController(ErrorAttributes errorAttributes) {
		this.errorAttributes = errorAttributes;
	}

	public CustomErrorController() {
		if (appErrorController == null) {
			appErrorController = new CustomErrorController(errorAttributes);
		}
	}

	/**
	 * Supports the HTML Error View
	 * 
	 * @param request
	 * @return
	 * @throws ValidationException 
	 * @throws IntrusionException 
	 */
	@RequestMapping(value = ERROR_PATH, produces = "text/html")
	public ModelAndView errorHtml(HttpServletRequest request) throws IntrusionException, ValidationException {
		//return new ModelAndView("redirect:" + errorPageURL, getErrorAttributes(request, false));
		// https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/sc-test/#/error
	    return new ModelAndView("redirect:" + validator.getValidInput("getRequestURL in errorHtml", request.getRequestURL().toString(), "HTTPURL", request.getRequestURL().toString().length(), true)
        .replaceAll(validator.getValidInput("getRequestURI in doFilter", request.getRequestURI().toString(), "HTTPURI", request.getRequestURI().toString().length(), true), "") + errorPageURL, getErrorAttributes(request, false));

	}

	/**
	 * Supports other formats like JSON, XML
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = ERROR_PATH)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
		Map<String, Object> body = getErrorAttributes(request, getTraceParameter(request));
		HttpStatus status = getStatus(request);
		return new ResponseEntity<Map<String, Object>>(body, status);
	}

	/**
	 * Returns the path of the error page.
	 *
	 * @return the error path
	 */
	@Override
	public String getErrorPath() {
		return ERROR_PATH;
	}

	private boolean getTraceParameter(HttpServletRequest request) {
		String parameter = request.getParameter("trace");
		if (parameter == null) {
			return false;
		}
		return !"false".equals(parameter.toLowerCase());
	}

	private Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
		RequestAttributes requestAttributes = new ServletRequestAttributes(request);
		Map<String, Object> map = this.errorAttributes.getErrorAttributes(requestAttributes, includeStackTrace);
		String URL = request.getRequestURL().toString();
		// map.put("URL", URL);
		// map.put("exception", "myexception");
		map.put("uimessage", request.getAttribute("uiMessage"));
		map.put("devMessage", request.getAttribute("devMessage"));
		map.put("status", request.getAttribute("status"));
		logger.debug("AppErrorController.method [error info]: status-" + map.get("status") + ", request url-" + URL);
		return map;
	}

	private HttpStatus getStatus(HttpServletRequest request) {
		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
		if (statusCode != null) {
			try {
				return HttpStatus.valueOf(statusCode);
			} catch (Exception ex) {
			}
		}
		return HttpStatus.INTERNAL_SERVER_ERROR;
	}

}