package com.ge.supplierconn.exception;


public class FileSizeTooLargeException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2663142590103460668L;
	
	

	public FileSizeTooLargeException() {

		super();
		// TODO Auto-generated constructor stub
	}

	public FileSizeTooLargeException(String arg0, Throwable arg1) {

		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public FileSizeTooLargeException(String arg0) {

		super(arg0);
		// TODO Auto-generated constructor stub
	}

	@Override
	public synchronized Throwable getCause() {

		// TODO Auto-generated method stub
		return super.getCause();
	}

	@Override
	public String getMessage() {

		// TODO Auto-generated method stub
		return super.getMessage();
	}

	@Override
	public String toString() {

		// TODO Auto-generated method stub
		return super.toString();
	}

	
}
