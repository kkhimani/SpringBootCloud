package com.ge.supplierconn;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Pattern;

import org.springframework.core.io.ByteArrayResource;

public class FileMessageResource extends ByteArrayResource {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((filename == null) ? 0 : filename.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileMessageResource other = (FileMessageResource) obj;
		if (filename == null) {
			if (other.filename != null)
				return false;
		} else if (!filename.equals(other.filename))
			return false;
		return true;
	}

	/**
	 * The filename to be associated with the {@link MimeMessage} in the form
	 * data.
	 */
	private final String filename;

	/**
	 * Constructs a new {@link MimeMessageRe
	 * 
	 * @param byteArray
	 *            A byte array containing data from a {@link MimeMessage}.
	 * @param filename
	 *            The filename to be associated with the {@link MimeMessage} in
	 *            the form data.
	 * @throws UnsupportedEncodingException 
	 */
	public FileMessageResource(final byte[] byteArray, final String filename) throws UnsupportedEncodingException {
		super(byteArray);
		this.filename =encodeNonUSFilename( filename);
	}

	@Override
	public String getFilename() {
		return filename;
	}
	
	private String encodeNonUSFilename(final String filename) throws UnsupportedEncodingException
    {

        String REGEX_FILENAME = "^[a-zA-Z0-9!@#$%^&{}\\[\\]()_+\\-=,.~'` ]{1,255}$";
        Pattern pattern = Pattern.compile(REGEX_FILENAME);
        StringBuilder encoddedString = new StringBuilder();

        for (int i = 0; i < filename.length(); i++)
        {
            char character = filename.charAt(i);

            String tempString = String.valueOf(character);

            if (!(pattern.matcher(tempString).matches()))
            {
                tempString = URLEncoder.encode(tempString, "UTF-8");
            }

            encoddedString.append(tempString);

        }

        return encoddedString.toString();
    }
}
