package com.ge.supplierconn.rest.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.net.URI;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.MultipartConfigElement;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.catalina.connector.Connector;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Validator;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.context.embedded.MultipartConfigFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.MultipartFilter;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.DispatcherServlet;

import com.ge.supplierconn.FileMessageResource;
import com.ge.supplierconn.HeaderRequestInterceptor;
import com.ge.supplierconn.exception.EurekaDownException;
import com.ge.supplierconn.exception.FileSizeTooLargeException;
import com.ge.supplierconn.model.UUIDGenerator;

@EnableZuulProxy
@RestController
@EnableDiscoveryClient
@EnableAutoConfiguration
public class APIGatewayController {
	@Autowired
	private LoadBalancerClient loadBalancer;
	private static final Logger LOG = LoggerFactory.getLogger(APIGatewayController.class);
	// @Autowired
	// private Environment env;
	private RestTemplate restTemplate = new RestTemplate();
	// ResponseVO responseVO = new ResponseVO();

	@Value("${security.oauth2.resource.userInfoUri}")
	private String uaa_userInfoUri;

	@Value("${maxFileSizeVal}")
	private int fileSize;
	
	@Value("${maxUploadFileSize}")
	private int maxUploadFileSize;
	
	
	private Validator validator = ESAPI.validator();

	@CrossOrigin
	@RequestMapping(value = "/{appName}/**", method = RequestMethod.GET)
	@ApiOperation(value = "getData", notes = "This method handles get Request")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public String getData(
			@ApiParam(name = "appName", value = "Enter appName :") @PathVariable("appName") String appName,
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)

					throws Exception {

		LOG.info("inside getData is: ");
		LOG.info("serviceName is:" + validator.getValidInput("appName in getData", appName, "appName", appName.length(), true));
		LOG.info("requestHeaders are:" + requestHeaders);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", request.getHeader("Authorization"));
		headers.setAll(requestHeaders);
		headers.setAccept(Collections.singletonList(MediaType.parseMediaType(MediaType.APPLICATION_JSON_UTF8_VALUE)));
		String serviceName = validator.getValidInput("appName in getData", appName, "appName", appName.length(), true);
		String action = validator.getValidInput("getRequestURI in getData", request.getRequestURI(), "HTTPURI", request.getRequestURI().length(), true).replace("/" + validator.getValidInput("appName in getData", appName, "appName", appName.length(), true), "").trim();

		URI uri = getServiceUrl(serviceName);

		String url = null;
		if (request.getQueryString() != null) {
			url = uri + "/" + action + "?" + validator.getValidInput("request.getQueryString() in getData", request.getQueryString(), "HTTPQueryString", request.getQueryString().length(), true);
		} else {
			url = uri + "/" + action;
		}
		LOG.info("----------------url is-----------------" + url);

		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
		interceptors.add(new HeaderRequestInterceptor("Accept", MediaType.APPLICATION_JSON_VALUE));
		restTemplate.setInterceptors(interceptors);

		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<?> requestObj = new HttpEntity<>(headers);
		ResponseEntity<String> resultStr = restTemplate.exchange(url, HttpMethod.GET, requestObj, String.class);
		/*
		 * ResponseEntity<String> resultStr = restTemplate.getForEntity(url,
		 * String.class); LOG.info("Get http-status: {}", resultStr != null ?
		 * resultStr.toString() + "******" + resultStr.hasBody() + "******" +
		 * resultStr.getBody() + " ***** " + resultStr.getStatusCode() : null);
		 */

		return resultStr != null ? resultStr.getBody() : null;
	}

	@CrossOrigin
	@RequestMapping(value = "/{appName}/**", method = RequestMethod.PUT)
	@ApiOperation(value = "putData", notes = "This method handles put Request")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> putData(
			@ApiParam(name = "postData", value = "Enter postData :") @Valid @RequestBody(required = false) String postData,
			@ApiParam(name = "appName", value = "Enter appName :") @PathVariable("appName") String appName,
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders,
			@ApiParam(name = "requestParams", value = "Enter requestParams :") @Valid  @RequestParam(required = false) MultiValueMap<String, Object> requestParams)
					throws Exception {
		LOG.info("inside putData::::");
		ResponseEntity<String> resultStr = null;
		/*
		 * LOG.info("postData is: " + postData); LOG.info("serviceName is:" +
		 * appName); LOG.info("requestHeaders are:" + requestHeaders);
		 */
		HttpHeaders headers = new HttpHeaders();
		if(validator.isValidInput("requestHeaders in putData", requestHeaders.toString(), "HTTPHeaderValue",requestHeaders.toString().length(), true))
			headers.setAll(requestHeaders);
		headers.setAccept(Collections.singletonList(MediaType.parseMediaType(MediaType.APPLICATION_JSON_UTF8_VALUE)));
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
		interceptors.add(new HeaderRequestInterceptor("Accept", MediaType.APPLICATION_JSON_VALUE));
		restTemplate.setInterceptors(interceptors);
		String serviceName = validator.getValidInput("appName in putData", appName, "appName", appName.length(), true);
		String action = validator.getValidInput("getRequestURI in putData", request.getRequestURI(), "HTTPURI", request.getRequestURI().length(), true).replace("/" + validator.getValidInput("appName in putData", appName, "appName", appName.length(), true), "").trim();
		URI uri = getServiceUrl(serviceName);
		String url = null;
		if (request.getQueryString() != null) {
			url = uri + "/" + action + "?" + validator.getValidInput("request.getQueryString() in putData", request.getQueryString(), "HTTPQueryString", request.getQueryString().length(), true);
		} else {
			url = uri + "/" + action;
		}
		LOG.info("-------url is--------------" + url);
		if (requestHeaders != null && requestHeaders.get("content-type") != null) {
			String contentType = requestHeaders.get("content-type");
			// addMessageConverters(contentType);
			if (contentType.contains("multipart/form-data")) {

				MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) request;
				// if (multiPartRequest != null) {

				MultiValueMap<String, Object> parts = new LinkedMultiValueMap<String, Object>();
				parts.putAll(requestParams);
				Iterator<String> iterator = multiPartRequest.getFileNames();
				if (iterator != null && multiPartRequest.getFiles("file") != null
						&& multiPartRequest.getFiles("file").size() > 0) {

					while (iterator.hasNext()) {
						MultipartFile file = multiPartRequest.getFile(iterator.next());
						if (file != null && file.getBytes() != null && file.getOriginalFilename() != null) {
							if(file.getSize()>maxUploadFileSize)
							{
								throw new FileSizeTooLargeException("file size ="+file.getSize());
							}
							parts.add("file", new FileMessageResource(file.getBytes(), file.getOriginalFilename()));
						}
					}

				}
				// LOG.info("Parts is::" + parts);
				HttpEntity<MultiValueMap<String, Object>> requestObjMulti = new HttpEntity<MultiValueMap<String, Object>>(
						parts, headers);
				LOG.info("Before calling restTemplate");
				resultStr = restTemplate.exchange(url, HttpMethod.PUT, requestObjMulti, String.class);
				// }
			} else {
				headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
				//HttpEntity<String> requestObj = new HttpEntity<String>(validator.getValidInput("postData in putdata", postData, "postData", postData.length(), true), headers);
				HttpEntity<String> requestObj = new HttpEntity<String>(postData, headers);
				resultStr = restTemplate.exchange(url, HttpMethod.PUT, requestObj, String.class);
				LOG.info("returning");

			}
		} else {
			headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
			//HttpEntity<String> requestObj = new HttpEntity<String>(validator.getValidInput("postData in putdata", postData, "postData", postData.length(), true), headers);
			HttpEntity<String> requestObj = new HttpEntity<String>(postData, headers);
			resultStr = restTemplate.exchange(url, HttpMethod.PUT, requestObj, String.class);

		}
		/*
		 * ResponseEntity<String> resultStr = restTemplate.getForEntity(url,
		 * String.class); if (resultStr != null) { LOG.info(
		 * "PUT http-status: {}", resultStr != null ? resultStr.toString() +
		 * "******" + resultStr.hasBody() + "******" + resultStr.getBody() +
		 * " ***** " + resultStr.getStatusCode() : null); }
		 */
		return resultStr;
	}

	@CrossOrigin
	@RequestMapping(value = "/{appName}/**", method = RequestMethod.DELETE)
	@ApiOperation(value = "deleteData", notes = "This method handles delete Request")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> deleteData(
			@ApiParam(name = "postData", value = "Enter postData :") @Valid @RequestBody(required = false) String postData,
			@ApiParam(name = "appName", value = "Enter appName :") @PathVariable("appName") String appName,
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {

		LOG.info("inside deleteData:::");
		/*
		 * LOG.info("postData is: " + postData); LOG.info("serviceName is:" +
		 * appName); LOG.info("requestHeaders are:" + requestHeaders);
		 */
		HttpHeaders headers = new HttpHeaders();
		if(validator.isValidInput("requestHeaders in deleteData", requestHeaders.toString(), "HTTPHeaderValue",requestHeaders.toString().length(), true))
			headers.setAll(requestHeaders);
		headers.setAccept(Collections.singletonList(MediaType.parseMediaType(MediaType.APPLICATION_JSON_UTF8_VALUE)));
		String serviceName = validator.getValidInput("appName in deleteData", appName, "appName", appName.length(), true);
		String action = validator.getValidInput("getRequestURI in deleteData", request.getRequestURI(), "HTTPURI", request.getRequestURI().length(), true).replace("/" + validator.getValidInput("appName in deleteData", appName, "appName", appName.length(), true), "").trim();
		URI uri = getServiceUrl(serviceName);
		String url = null;
		if (request.getQueryString() != null) {
			url = uri + "/" + action + "?" + validator.getValidInput("request.getQueryString() in deleteData", request.getQueryString(), "HTTPQueryString", request.getQueryString().length(), true);
		} else {
			url = uri + "/" + action;
		}
		LOG.info("url is:" + url);
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
		interceptors.add(new HeaderRequestInterceptor("Accept", MediaType.APPLICATION_JSON_VALUE));
		restTemplate.setInterceptors(interceptors);
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		//HttpEntity<String> requestObj = new HttpEntity<String>(validator.getValidInput("postData in deletedata", postData, "postData", postData.length(), true), headers);
		HttpEntity<String> requestObj = new HttpEntity<String>(postData, headers);
		ResponseEntity<String> resultStr = restTemplate.exchange(url, HttpMethod.DELETE, requestObj, String.class);
		/*
		 * ResponseEntity<String> resultStr = restTemplate.getForEntity(url,
		 * String.class); LOG.info("Delete http-status: {}", resultStr != null ?
		 * resultStr.toString() + "******" + resultStr.hasBody() + "******" +
		 * resultStr.getBody() + " ***** " + resultStr.getStatusCode() : null);
		 */
		return resultStr;
	}

	@CrossOrigin
	@RequestMapping(value = "/{appName}/**", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "postData", notes = "This method handles post Request")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public String postData(
			@ApiParam(name = "postData", value = "Enter postData :") @Valid @RequestBody(required = false) String postData,
			@ApiParam(name = "appName", value = "Enter appName :") @PathVariable("appName") String appName,
			@ApiParam(name = "requestParams", value = "Enter requestParams :") @RequestParam(required = false) MultiValueMap<String, Object> requestParams,
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {

		LOG.info("inside postData is: ");
		LOG.info("postData is: " + postData);
		LOG.info("serviceName is:" + appName);
		LOG.info("requestParams is:" + requestParams);
		LOG.info("requestURI is:" + request.getRequestURI());
		LOG.info("QueryString is:" + request.getQueryString());
		LOG.info("requestHeaders is:" + requestHeaders);
		String serviceName = validator.getValidInput("appName in postData", appName, "appName", appName.length(), true);
		String action = validator.getValidInput("getRequestURI in postData", request.getRequestURI(), "HTTPURI", request.getRequestURI().length(), true).replace("/" + validator.getValidInput("appName in postData", appName, "appName", appName.length(), true), "").trim();
		ResponseEntity<String> resultStr = null;

		HttpHeaders headers = new HttpHeaders();
		if(validator.isValidInput("postData in putData", requestHeaders.toString(), "HTTPHeaderValue",requestHeaders.toString().length(), true))
			headers.setAll(requestHeaders);
		LOG.info("transaction_id for request headers:" + headers.get("X-PC-Transaction-ID"));
		// LOG.info("headers are:" + headers.toString());
		headers.setAccept(Collections.singletonList(MediaType.parseMediaType(MediaType.APPLICATION_JSON_UTF8_VALUE)));

		URI uri = getServiceUrl(serviceName);

		String url = null;
		if (request.getQueryString() != null)
		{
			url = uri + "/" + action + "?" + validator.getValidInput("request.getQueryString() in postData", request.getQueryString(), "HTTPQueryString", request.getQueryString().length(), true);
		} else
		{
			url = uri + "/" + action;
		}
		LOG.info("-------------url is--------------" + url);

		if (requestHeaders != null && requestHeaders.get("content-type") != null)

		{
			String contentType = requestHeaders.get("content-type");
			// addMessageConverters(contentType);
			if (contentType.contains("multipart/form-data")) {

				MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) request;
				// if (multiPartRequest != null) {

				MultiValueMap<String, Object> parts = new LinkedMultiValueMap<String, Object>();
				parts.putAll(requestParams);
				LOG.info("-------------X-PC-Transaction-ID is--------------" + parts.get("X-PC-Transaction-ID"));
				Iterator<String> iterator = multiPartRequest.getFileNames();
				if (iterator != null && multiPartRequest.getFiles("file") != null
						&& multiPartRequest.getFiles("file").size() > 0) {

					while (iterator.hasNext()) {
						MultipartFile file = multiPartRequest.getFile(iterator.next());
						if (file != null && file.getBytes() != null && file.getOriginalFilename() != null) {
							if(file.getSize()>maxUploadFileSize)
							{
								throw new FileSizeTooLargeException("file size ="+file.getSize());
							}
							parts.add("file", new FileMessageResource(file.getBytes(), file.getOriginalFilename()));
						}
					}

				}
				// LOG.info("Parts is::" + parts);
				HttpEntity<MultiValueMap<String, Object>> requestObjMulti = new HttpEntity<MultiValueMap<String, Object>>(
						parts, headers);
				LOG.info("Before calling restTemplate");
				resultStr = restTemplate.exchange(url, HttpMethod.POST, requestObjMulti, String.class);
				// }
			} else {
				headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
				//HttpEntity<String> requestObj = new HttpEntity<String>(validator.getValidInput("postData in postdata", postData, "postData", postData.length(), true), headers);
				HttpEntity<String> requestObj = new HttpEntity<String>(postData, headers);
				resultStr = restTemplate.exchange(url, HttpMethod.POST, requestObj, String.class);
				LOG.info("returning");

			}
		} else

		{
			headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
			//HttpEntity<String> requestObj = new HttpEntity<String>(validator.getValidInput("postData in postdata", postData, "postData", postData.length(), true), headers);
			HttpEntity<String> requestObj = new HttpEntity<String>(postData, headers);
			resultStr = restTemplate.exchange(url, HttpMethod.POST, requestObj, String.class);

		}
		return resultStr != null ? resultStr.getBody() : null;

	}

	public URI getServiceUrl(String serviceId) throws EurekaDownException {

		URI uri = null;
		try {

			ServiceInstance instance = loadBalancer.choose(serviceId);
			if (instance != null && instance.getUri() != null) {
				uri = instance.getUri();
				LOG.info("--------Resolved serviceId '{}' to URL '{}'----------", serviceId, uri);
			}

		} catch (RuntimeException e) {
			// Eureka not available, use fallback
			LOG.error("Failed to resolve serviceId '{}'. Fallback to URL '{}'.", serviceId, uri);
			throw new EurekaDownException("Service Registry is down", e);
			/*
			 * uri = URI.create(fallbackUri); LOG.warn(
			 * "Failed to resolve serviceId '{}'. Fallback to URL '{}'.",
			 * serviceId, uri);
			 */
		}
		return uri;
	}

	@Bean
	MultipartConfigElement multipartConfigElement() {

		MultipartConfigFactory factory = new MultipartConfigFactory();
		factory.setMaxFileSize("5120MB");
		factory.setMaxRequestSize("5120MB");
		return factory.createMultipartConfig();
	}

	@Bean(name = DispatcherServlet.MULTIPART_RESOLVER_BEAN_NAME)
	@ConditionalOnMissingBean(MultipartResolver.class)
	public StandardServletMultipartResolver multipartResolver() {

		return new StandardServletMultipartResolver();
	}

	@Bean
	public FilterRegistrationBean multipartFilter() {

		FilterRegistrationBean filterRegBean = new FilterRegistrationBean();
		filterRegBean.setFilter(new MultipartFilter());
		List<String> urlPatterns = new ArrayList<String>();
		urlPatterns.add("/*");
		filterRegBean.setUrlPatterns(urlPatterns);
		return filterRegBean;
	}

	@Bean
	public TomcatEmbeddedServletContainerFactory containerFactory() {
		return new TomcatEmbeddedServletContainerFactory() {
			protected void customizeConnector(Connector connector) {
				super.customizeConnector(connector);
				if (connector.getProtocolHandler() instanceof AbstractHttp11Protocol) {
					((AbstractHttp11Protocol<?>) connector.getProtocolHandler()).setMaxSwallowSize(fileSize);

				}
			}
		};

	}

	public void addMessageConverters(String contentType) {

		LOG.info("inside addMessageConverters:::");
		List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();

		if (contentType.contains("multipart/form-data")) {
			FormHttpMessageConverter formConverter = new FormHttpMessageConverter();
			formConverter.setCharset(Charset.forName("UTF8"));
			messageConverters.add(formConverter);
		}
		List<MediaType> supportedjsonMediaTypes = new ArrayList<MediaType>();
		supportedjsonMediaTypes.add(new MediaType("text", "javascript"));
		supportedjsonMediaTypes.add(new MediaType("multipart", "form-data"));
		supportedjsonMediaTypes.add(new MediaType("application", "octet-stream"));
		supportedjsonMediaTypes.add(new MediaType("application", "json"));
		supportedjsonMediaTypes.add(new MediaType("application", "xhtml+xml"));
		supportedjsonMediaTypes.add(new MediaType("application", "xml"));
		supportedjsonMediaTypes.add(new MediaType("application", "atom+xml"));
		supportedjsonMediaTypes.add(new MediaType("application", "x-www-form-urlencoded"));
		supportedjsonMediaTypes.add(new MediaType("image", "gif"));
		supportedjsonMediaTypes.add(new MediaType("image", "jpeg"));
		supportedjsonMediaTypes.add(new MediaType("image", "png"));
		MappingJackson2HttpMessageConverter ObjMappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
		ObjMappingJackson2HttpMessageConverter.setSupportedMediaTypes(supportedjsonMediaTypes);
		messageConverters.add(ObjMappingJackson2HttpMessageConverter);

		List<MediaType> supportedstringMediaTypes = new ArrayList<MediaType>();
		supportedstringMediaTypes.add(new MediaType("text", "plain"));
		supportedstringMediaTypes.add(new MediaType("text", "xml"));
		StringHttpMessageConverter objStringHttpMessageConverter = new StringHttpMessageConverter(
				Charset.forName("UTF8"));
		objStringHttpMessageConverter.setSupportedMediaTypes(supportedstringMediaTypes);
		messageConverters.add(objStringHttpMessageConverter);

		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());

		restTemplate.setMessageConverters(messageConverters);
	}
}
