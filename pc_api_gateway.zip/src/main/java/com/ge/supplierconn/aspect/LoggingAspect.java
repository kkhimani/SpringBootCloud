package com.ge.supplierconn.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class LoggingAspect {

	private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

	public void logBefore(JoinPoint joinPoint) {
		if (joinPoint != null && joinPoint.getTarget() != null && joinPoint.getSignature() != null) {
			logger.info(
					"***********************************************************************************************");

			logger.info("Method is : " + joinPoint.getTarget().getClass() + "." + joinPoint.getSignature().getName()
					+ "  Starts");
			logger.info(
					"***********************************************************************************************");
		}
	}

	@After("execution(* com.ge.supplierconn..*(..))")
	public void logAfter(JoinPoint joinPoint) {
		if (joinPoint != null && joinPoint.getTarget() != null && joinPoint.getSignature() != null) {
			logger.info(
					"***********************************************************************************************");

			logger.info("Method is : " + joinPoint.getTarget().getClass() + "." + joinPoint.getSignature().getName()
					+ "  ends");

			logger.info(
					"***********************************************************************************************");
		}
	}

}