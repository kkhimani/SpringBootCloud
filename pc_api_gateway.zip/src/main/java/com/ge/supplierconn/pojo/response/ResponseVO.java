/**
 * 
 */
package com.ge.supplierconn.pojo.response;

public class ResponseVO
{
	private Integer httpStatusCode;
	private String errorCode;
	private String uiMessage;
	private String devMessage;

	public ResponseVO(Integer httpStatusCode, String errorCode, String uiMessage, String devMessage) {
		super();
		this.httpStatusCode = httpStatusCode;
		this.errorCode = errorCode;
		this.uiMessage = uiMessage;
		this.devMessage = devMessage;
	}

	public Integer getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(Integer httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getUiMessage() {
		return uiMessage;
	}

	public void setUiMessage(String uiMessage) {
		this.uiMessage = uiMessage;
	}

	public String getDevMessage() {
		return devMessage;
	}

	public void setDevMessage(String devMessage) {
		this.devMessage = devMessage;
	}

	public ResponseVO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
