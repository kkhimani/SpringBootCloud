package com.ge.supplierconn.security.dto;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UserDetailsDto implements UserDetails
{

    /**
	 * 
	 */
	private static final long serialVersionUID = -780083601403559595L;
	private String username;
    private boolean accountNonExpired;
    private boolean accountNonLocked;
    private boolean credentialsNonExpired;
    private boolean enabled = false;
	private boolean termsAndConditionsAccepted = false ;
	private List<UserRolesDto> roles;
    private Set<UserRoleDto> role = new HashSet<>();

    public static final UserDetailsDto GUEST_USER = new UserDetailsDto("Guest", true, true, true, true, false, Collections.EMPTY_LIST, Collections.EMPTY_SET);

    public UserDetailsDto()
    {
    }

    public UserDetailsDto(String username, boolean accountNonExpired, boolean accountNonLocked, boolean credentialsNonExpired, boolean enabled, boolean termsAndConditionsAccepted, List<UserRolesDto> roles, Set<UserRoleDto> role)
    {
        this.username = username;
        this.accountNonExpired = accountNonExpired;
        this.accountNonLocked = accountNonLocked;
        this.credentialsNonExpired = credentialsNonExpired;
        this.enabled = enabled;
		this.termsAndConditionsAccepted = termsAndConditionsAccepted;
		this.roles = roles;
        this.role = role;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities()
    {
        return role;
    }

    @Override
    public String getPassword()
    {
        return null;
    }

    @Override
    public String getUsername()
    {
        return username;
    }

    @Override
    public boolean isAccountNonExpired()
    {
        return accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked()
    {
        return accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired()
    {
        return credentialsNonExpired;
    }

    @Override
    public boolean isEnabled()
    {
        return enabled;
    }

	public boolean isTermsAndConditionsAccepted()
    {
        return termsAndConditionsAccepted;
    }
	
	public List<UserRolesDto> getRoles()
    {
        return roles;
    }

    @Override
    public String toString()
    {
        return "UserInfo: Name = " + username;
    }
}
