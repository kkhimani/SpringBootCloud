
package com.ge.supplierconn.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.stereotype.Component;

import com.ge.supplierconn.security.filter.AuthFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@ComponentScan("com.ge.supplierconn.*")
@EnableAutoConfiguration
@Component
@Order(10)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
{
    @Autowired
    private AuthFilter authFilter;

    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
    	System.setProperty("http.proxyHost", "cis-cinci-pitc-ssow.proxy.corporate.gtm.ge.com");
		System.setProperty("http.proxyPort", "80");
		System.setProperty("https.proxyHost", "cis-cinci-pitc-ssow.proxy.corporate.gtm.ge.com");
		System.setProperty("https.proxyPort", "80");
		
        http.authorizeRequests().antMatchers("/", "/sc/**", "/sc-test/**","/pc-admin-ui/**","/logout/**","/login/**","/logoff/**","/swagger-ui.html/**","/oauth-token/**","/pc_document_management/v2/supplier/document/download/**","/info/**").permitAll().anyRequest().authenticated();
		http.addFilterBefore(authFilter, BasicAuthenticationFilter.class);
        http.csrf().disable().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.ALWAYS);
    }

    @Override
    public void configure(WebSecurity web) throws Exception
    {
        web.ignoring().antMatchers("/sc/js/**", "/sc-test/js/**","/pc-admin-ui/assets/**","pc-admin-ui/fonts/**");
    }
}
