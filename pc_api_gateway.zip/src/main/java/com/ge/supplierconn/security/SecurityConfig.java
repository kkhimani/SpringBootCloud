package com.ge.supplierconn.security;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.repository.query.spi.EvaluationContextExtension;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.data.repository.query.SecurityEvaluationContextExtension;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Configuration
@ComponentScan("com.ge.supplierconn.*")
@EnableAutoConfiguration
public class SecurityConfig extends ResourceServerConfigurerAdapter {

	@Override
	public void configure(HttpSecurity http) throws Exception {
		if (http != null && http.authorizeRequests() != null
				&& http.authorizeRequests().antMatchers("/", "/sc/**", "/sc-test/**","/pc-admin-ui/**") != null
				&& http.authorizeRequests().antMatchers("/", "/sc/**", "/sc-test/**","/pc-admin-ui/**").permitAll() != null
				&& http.authorizeRequests().antMatchers("/", "/sc/**", "/sc-test/**","/pc-admin-ui/**").permitAll()
						.anyRequest() != null) {
			http.authorizeRequests().antMatchers("/", "/sc/**", "/sc-test/**","/pc-admin-ui/**", "/logout/**", "/login/**", "/logoff/**","/swagger-ui.html/**","/oauth-token/**","/pc-document-management/v2/supplier/document/download/**","/info/**")
					.permitAll().anyRequest().authenticated();
		}

	}

	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.resourceId("openid");
	}

	@Bean
	public EvaluationContextExtension securityEvaluationContextExtension() {
		return new SecurityEvaluationContextExtension();
	}

}
