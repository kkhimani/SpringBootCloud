package com.ge.supplierconn.security.datasource.impl;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.ge.supplierconn.redis.RedisClientService;
import com.ge.supplierconn.security.datasource.UserDataSource;
import com.ge.supplierconn.security.dto.UserDetailsDto;
import com.ge.supplierconn.security.dto.UserRoleDto;

@Component
public class RedisUserDataSourceImpl implements UserDataSource {

	@Autowired
	private RedisClientService redisClientService;
	@Autowired
	private ObjectMapper objectMapper;

	private Logger log = LoggerFactory.getLogger(RedisUserDataSourceImpl.class);

	@PostConstruct
	public void init() {
		SimpleModule module = new SimpleModule("MyModuleName", new Version(1, 0, 0, "SNAPSHOT", "test", "test"));
		module.addAbstractTypeMapping(GrantedAuthority.class, UserRoleDto.class);
		objectMapper.registerModule(module);
	}

	@Override
	public UserDetailsDto getUser(String key) throws JsonParseException, JsonMappingException, IOException {
		log.info("Key Value = " + key);
		if (key != null && redisClientService.getValue(key) != null) {
			log.info("Redis value = " + redisClientService.getValue(key));
			return objectMapper.readValue(redisClientService.getValue(key), UserDetailsDto.class);
		} else {
			return UserDetailsDto.GUEST_USER;
		}

	}
}
