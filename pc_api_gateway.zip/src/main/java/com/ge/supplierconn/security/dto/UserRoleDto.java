package com.ge.supplierconn.security.dto;

import org.springframework.security.core.GrantedAuthority;

public class UserRoleDto implements GrantedAuthority
{

    private int id;
    private String authority;
    private String description;

    public UserRoleDto()
    {
    }

    public UserRoleDto(String code)
    {
        this.authority = code;
    }

    @Override
    public String getAuthority()
    {
        return authority;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

}
