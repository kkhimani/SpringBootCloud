package com.ge.supplierconn.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Validator;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ge.supplierconn.security.datasource.UserDataSource;
import com.ge.supplierconn.security.dto.UserDetailsDto;

@Component
public class AuthFilter extends OncePerRequestFilter {

	public static final String AUTH_HEADER_NAME = "Authorization";

	@Autowired
	private UserDataSource userDataSource;

	private Validator validator = ESAPI.validator();

	private static final Logger LOG = LoggerFactory.getLogger(AuthFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String token = null;
		try {
			if (request.getHeader(AUTH_HEADER_NAME) != null) {

				token = validator.getValidInput("Authorization in doFilterInternal",
						request.getHeader(AUTH_HEADER_NAME), "HTTPCookieValue",
						request.getHeader(AUTH_HEADER_NAME).length(), true);

			}
			if (token != null && !token.equalsIgnoreCase("")) {

				UserDetailsDto user = userDataSource.getUser(token);
				if (user != null && user.getAuthorities() != null) {
					LOG.info("Inserting user: " + user.toString());
					Authentication authentication = new PreAuthenticatedAuthenticationToken(user, "pass",
							user.getAuthorities());
					SecurityContextHolder.getContext().setAuthentication(authentication);
					request.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
							SecurityContextHolder.getContext());
				}

			}
			filterChain.doFilter(request, response);
		} catch (IntrusionException | ValidationException e) {
			// TODO Auto-generated catch block
			try {
				LOG.error("Exception is: " + e.getMessage());
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}