package com.ge.supplierconn.security.rest;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.supplierconn.filter.CORSFilter;
import com.ge.supplierconn.redis.RedisClientService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class SecurityController {
	private static final Logger LOG = LoggerFactory.getLogger(SecurityController.class);

	@Value("${security.oauth2.resource.userInfoUri}")
	private String uaa_userInfoUri;
	
	@Value("${security.oauth2.client.accessTokenUri}")
	private String uaa_token;
	
	@Value("${security.oauth2.client.client-id}")
	private String uaa_id;

	@Value("${security.oauth2.client.client-secret}")
	private String uaa_secret;

	@Autowired
	private ServletContext servletContext;

	@Autowired
	private RedisClientService redisClientService;
	
	private Validator validator = ESAPI.validator();

	@RequestMapping(value = "/userinfo", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "getUserData", notes = "This method returns user details")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> getUserData(
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {
		JSONObject objtoken = null;
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		try {
			LOG.info("Inside getUserData()");
			httpClient = HttpClients.createDefault();
			List<Header> headers = new ArrayList<Header>();
			String auth = validator.getValidInput("Authorization in getuserdata", request.getHeader("Authorization"), "HTTPCookieValue", request.getHeader("Authorization").length(), true);
			headers.add(new BasicHeader("Authorization", auth));
			headers.add(new BasicHeader("Accept", "application/json"));
			HttpGet method = new HttpGet(uaa_userInfoUri);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			objtoken = new JSONObject(EntityUtils.toString(responseEntity));
			objtoken.put("user_id", objtoken.getString("user_name"));

		}
		/*
		 * catch (Exception e) { e.printStackTrace(); return
		 * ResponseEntity.status(HttpStatus.OK).body("{\"response\":\"" +
		 * e.getMessage() + "\"}"); }
		 */
		finally {

			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}

		}
		if(!(objtoken.toString().equals("")))
		{
		    return ResponseEntity.status(HttpStatus.OK).body(objtoken.toString());
		}
		return ResponseEntity.status(HttpStatus.OK).body(null);

	}

	@RequestMapping(value = "/getprofile", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "getProfile", notes = "This method returns user profile")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> getProfile(
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {
		JSONObject objtoken = null;
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		CloseableHttpResponse httpResponseInvalidToken = null;
		String responseValue = null;
		try {

			LOG.info("Inside getProfile() servletContext value = " + servletContext.getAttribute("sso_token"));
			String auth = "";
			if (servletContext.getAttribute("sso_token") == null) {
				auth = getTokenProfile();
			} else {
				auth = (String) servletContext.getAttribute("sso_token");
			}

			ResponseEntity<String> resultStr = getUserData(response, request, requestHeaders);
			objtoken = new JSONObject(resultStr.getBody());
			String sso = objtoken.getString("user_name");
			String query = URLEncoder
					.encode("{\"directoryBranch\": \"400\",\"permitAbbreviatedRecords\": \"true\",\"abbreviatedFieldList\": {\"field\": [\"georaclehrid\",\"givenName\",\"sn\",\"gessosupervisorid\",\"mail\"]},\"primaryKey\":{\"uid\":\""
							+ sso
							+ "\"}, \"fieldList\": {\"field\": [\"uid\",\"mail\",\"cn\",\"sn\",\"givenName\",\"gessosupervisorid\",\"georaclehrid\"]}}");
			String url = "https://api.ge.com/gecorp/GenericReadService/v1/ReadData?readData=" + query
					+ "&responsetype=json";
			httpClient = HttpClients.createDefault();
			List<Header> headers = new ArrayList<Header>();
			headers.add(new BasicHeader("Accept", "application/json"));
			headers.add(new BasicHeader("Authorization", auth));
			HttpPost method = new HttpPost(url);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			responseValue = EntityUtils.toString(responseEntity);
			if (responseValue.contains("Invalid token")) {
				auth = getTokenProfile();
				headers.add(new BasicHeader("Authorization", auth));
				method = new HttpPost(url);
				method.setHeaders(headers.toArray(new Header[headers.size()]));
				httpResponseInvalidToken = httpClient.execute(method);
				responseEntity = httpResponseInvalidToken.getEntity();
				responseValue = EntityUtils.toString(responseEntity);
			}

		} finally {

			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}
			if (httpResponseInvalidToken != null) {
				httpResponseInvalidToken.close();
			}

		}
		/*
		 * catch (Exception e) { e.printStackTrace(); return
		 * ResponseEntity.status(HttpStatus.OK).body("{\"response\":\"" +
		 * e.getMessage() + "\"}"); }
		 */
		return ResponseEntity.status(HttpStatus.OK).body(responseValue);
	}

	public String getTokenProfile() throws ClientProtocolException, IOException {

		LOG.info("Inside getProfile()");
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		String token = "";
		try {
			httpClient = HttpClients.createDefault();
			List<Header> headers = new ArrayList<Header>();
			headers.add(new BasicHeader("Accept", "application/json"));
			HttpPost method = new HttpPost(
					"https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id=GEGlobel_Supplier_Portal_Client&client_secret=Cr5wnxuJ5cdPeArRRaaT66RHwEhvhh2EusofhSoqhl1SagivHLI01zITjAWL0FJf&scope=GECorp_GenericReadService_CentralApp_ITRisk_API");
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			JSONObject objtoken = new JSONObject(EntityUtils.toString(responseEntity));
			token = objtoken.getString("token_type") + " " + objtoken.getString("access_token");
			servletContext.setAttribute("sso_token", token);
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}
		}
		return token;
	}

	@RequestMapping(value = "/userroles", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "getUserRoles", notes = "This method returns user roles")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> getUserRoles(
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {
		String auth = validator.getValidInput("Authorization in getuserroles", request.getHeader("Authorization"), "HTTPCookieValue", request.getHeader("Authorization").length(), true);
		if (auth != null && redisClientService.getValue(auth) != null) {
			return ResponseEntity.status(HttpStatus.OK).body(redisClientService.getValue(auth));
		}
        return ResponseEntity.status(HttpStatus.OK).body("");
	}
	
	@RequestMapping(value = "/refresh-token", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "getRefreshToken", notes = "This method returns refresh token details")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> getRefreshToken(
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		String code = validator.getValidInput("request.getParameter(token) in getuserroles", request.getParameter("token"), "HTTPCookieValue", request.getParameter("token").length(), true);
		JSONObject objtoken = null;
		CORSFilter objCORSFilter = new CORSFilter();
		try {
			LOG.info("Inside getRefreshToken()");			
			httpClient = HttpClients.createDefault();
			List<Header> headers = new ArrayList<Header>();
			String authHeader = "Basic "
					+ new String(Base64.encodeBase64((uaa_id + ":" + uaa_secret).getBytes(Charset.forName("UTF-8"))));
			headers.add(new BasicHeader("Content-Type", "application/x-www-form-urlencoded"));
			headers.add(new BasicHeader("Authorization", authHeader));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			org.apache.http.HttpEntity entity = new StringEntity(
					"grant_type=refresh_token&refresh_token=" + code);
			HttpPost method = new HttpPost(uaa_token);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			method.setEntity(entity);
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			code = EntityUtils.toString(responseEntity);
			if (code.contains("token_type"))
			{
				objtoken = new JSONObject(code);
				String token = objtoken.getString("token_type") + " " + objtoken.getString("access_token");			
				objCORSFilter.sendToken(request, token);				
			}
		}		
		finally {

			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}

		}
		return ResponseEntity.status(HttpStatus.OK)
				.body(code);

	}
	
	@RequestMapping(value = "/oauth-token", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "getOauthToken", notes = "This method returns token details")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "Continue", response = String.class),
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 400, message = "Passing invaid data", response = String.class),
			@ApiResponse(code = 422, message = "Unprocessed Data passed", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
	@ResponseBody
	public ResponseEntity<String> getOauthToken(
			@ApiParam(name = "response", value = "HttpServletResponse :") final HttpServletResponse response,
			@ApiParam(name = "request", value = "HttpServletRequest :") final HttpServletRequest request,
			@ApiParam(name = "requestHeaders", value = "Enter requestHeaders :") @RequestHeader(required = false) Map<String, String> requestHeaders)
					throws Exception {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;	
		String code = "";
		try {
			LOG.info("Inside getRefreshToken()");			
			httpClient = HttpClients.createDefault();
			List<Header> headers = new ArrayList<Header>();
			String authHeader = "Basic "
					+ new String(Base64.encodeBase64((uaa_id + ":" + uaa_secret).getBytes(Charset.forName("UTF-8"))));
			headers.add(new BasicHeader("Content-Type", "application/x-www-form-urlencoded"));
			headers.add(new BasicHeader("Authorization", authHeader));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			org.apache.http.HttpEntity entity = new StringEntity("grant_type=client_credentials");
			HttpPost method = new HttpPost(uaa_token);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			method.setEntity(entity);
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			code = EntityUtils.toString(responseEntity);
		}		
		finally {

			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}

		}
		return ResponseEntity.status(HttpStatus.OK)
				.body(code);

	}
}
