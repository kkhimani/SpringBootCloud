package com.ge.supplierconn.security.datasource;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.supplierconn.security.dto.UserDetailsDto;

public interface UserDataSource
{

    UserDetailsDto getUser(String key) throws JsonParseException, JsonMappingException, IOException;
}
