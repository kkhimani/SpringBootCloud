package com.ge.supplierconn.redis.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import com.ge.supplierconn.redis.RedisClientService;

@Service
public class RedisClientServiceImpl implements RedisClientService
{

    @Autowired
    private StringRedisTemplate template;

    @Override
    public String getValue(String key)
    {
        ValueOperations<String, String> ops = template.opsForValue();
        return ops.get(key);
    }

    @Override
    public void setValue(String key, String data)
    {
        ValueOperations<String, String> ops = template.opsForValue();
        ops.set(key, data);
    }

    @Override
    public boolean hasKeyForValue(String key)
    {
        return template.hasKey(key);
    }
}