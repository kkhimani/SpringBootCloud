package com.ge.supplierconn.redis;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.common.RedisServiceInfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;


@Configuration
@Profile("cloud")
public class Config {

	private static final Logger log = LoggerFactory.getLogger(Config.class);

	@Bean
    public RedisConnectionFactory redisConnectionFactory() {
        CloudFactory cloudFactory = new CloudFactory();
        Cloud cloud = cloudFactory.getCloud();

        return cloud.getServiceInfos().stream()
                .filter(si -> si instanceof RedisServiceInfo)
                .findFirst()
                .map(serviceInfo -> {
                    RedisServiceInfo redisServiceInfo = (RedisServiceInfo) serviceInfo;
                    JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
                    jedisConnectionFactory.setHostName(redisServiceInfo.getHost());
                    jedisConnectionFactory.setPort(redisServiceInfo.getPort());
                    jedisConnectionFactory.setPassword(redisServiceInfo.getPassword());
                    jedisConnectionFactory.setUsePool(true);
                    return jedisConnectionFactory;
                })
                .orElseThrow(() -> new RuntimeException("Redis service not found"));
    }

    @Bean
    public RedisTemplate redisTemplate() {
        return new StringRedisTemplate(redisConnectionFactory());
    }

    @Bean
    public StringRedisTemplate stringRedisTemplate() {
        return new StringRedisTemplate(redisConnectionFactory());
    }

	private JSONObject getCredentials(String envVarName, String envObj, String subObj) throws Exception {
		log.info("In getCredentials() : ");

		JSONObject vcap_services = null;
		JSONObject credentials = null;

		String vcap_services_string = System.getenv(envVarName);
		if (vcap_services_string != null) {
			vcap_services = new JSONObject(vcap_services_string);

			JSONArray predix_blobstore = vcap_services.getJSONArray(envObj);
			if (predix_blobstore != null) {

				credentials = predix_blobstore.getJSONObject(0).getJSONObject(subObj);

			} else {
				log.error(envObj + " not bound to this application.  No environment variable found.");
			}
		} else {
			log.error("No " + envVarName + " environment variable.");
		}

		return (credentials);

	}

}
