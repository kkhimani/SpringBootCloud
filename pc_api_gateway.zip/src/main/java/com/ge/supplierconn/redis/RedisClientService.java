package com.ge.supplierconn.redis;

public interface RedisClientService
{

    String getValue(String key);

    void setValue(String key, String data);

    boolean hasKeyForValue(String key);

}
