package com.ge.supplierconn.filter;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Encoder;
import org.owasp.esapi.Validator;
import org.owasp.esapi.errors.EncodingException;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.owasp.esapi.reference.DefaultEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.ge.supplierconn.model.UUIDGenerator;
import com.ge.supplierconn.redis.RedisClientService;
import com.ge.supplierconn.security.datasource.UserDataSource;
import com.ge.supplierconn.security.dto.UserDetailsDto;
import com.ge.supplierconn.security.dto.UserRolesDto;

@Component
@EnableAutoConfiguration
public class CORSFilter implements Filter {

	private static final Logger LOG = LoggerFactory.getLogger(CORSFilter.class);

	@Value("${security.oauth2.client.userAuthorizationUri}")
	private String uaa_url;

	@Value("${security.oauth2.client.client-id}")
	private String uaa_client;

	@Value("${security.oauth2.client.accessTokenUri}")
	private String uaa_token;

	@Value("${security.oauth2.client.client-id}")
	private String uaa_id;

	@Value("${security.oauth2.client.client-secret}")
	private String uaa_key;

	@Value("${security.oauth2.resource.userInfoUri}")
	private String uaa_userInfoUri;

	@Value("${logout}")
	private String logout;

	@Autowired
	RedisClientService redisClientService;

	@Autowired
	private UserDataSource userDataSource;

	private Validator validator = ESAPI.validator();
	
	public static final String EMPTY = "";
    public static final String EQUAL = "=";
    public static final String SLASH = "/";
    public static final String BLACK_SPACE = " ";
    public static final String QUESTION_MARK = "?";
    public static final String AMP = "&";
    public static final String BASIC = "Basic";
    public static final String AUTH_HEADER_NAME = "Authorization";
    public static final String BASIC_HEADER_NAME = BASIC + BLACK_SPACE;
    public static final String AUTH_AUTHORIZE = "oauth" + SLASH + "authorize";
    public static final String CODE = "code";
    public static final String LOGOUT = "logout";
    public static final String LOGOFF = "logoff";
    public static final String REDIRECT = "redirect";
    public static final String SC_TOKEN = "sc_token";
    public static final String SC_REFRESH_TOKEN = "sc_refresh_token";
    public static final String SC_EXPIRES_IN = "sc_expires_in";
    public static final String SC_SSO = "sc_sso";
    public static final String TOKEN = "token";
    public static final String TOKEN_TYPE = "token_type";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String EXPIRES_IN = "expires_in";
    public static final String USER_NAME = "user_name";
    public static final String SUPPLIER = "Supplier";
	public static final String SUPPLIER_ACC_RECE = "Supplier Accounts Receivable";
	public static final String SUPPLIER_ORD_FUL = "Supplier Order Fulfillment";
	public static final String SUPPLIER_SALES = "Supplier Sales";
	public static final String SOURCING = "Sourcing";
	public static final String REDIRECT_URI = AMP + "redirect_uri" + EQUAL;
	public static final String UAA_TOKEN = QUESTION_MARK + "response_type" + EQUAL + CODE + AMP + "client_id" + EQUAL;
    public static final String UAA_TOKEN_SC_REDIRECT = "sc-test%2F";
	public static final String UAA_TOKEN_ADMIN_REDIRECT = "pc-admin-ui%2F";
    public static final String UAA_TOKEN_AUTH = "grant_type=authorization_code" + AMP + CODE + EQUAL;
    public static final String UAA_TOKEN_STATE = AMP + "state=secure";
	public static final String UAA_TOKEN_SC_UI = UAA_TOKEN_STATE + AMP + REDIRECT_URI;
	public static final String UAA_TOKEN_ADMIN_UI = UAA_TOKEN_STATE + AMP + REDIRECT_URI;
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws ServletException, IOException {
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;
		Map<String, String> requestHeaders = getHeadersInfo(request);
		MutableHttpServletRequest mutableRequest = new MutableHttpServletRequest(request);
		if (requestHeaders != null && requestHeaders.get("x-pc-transaction-id") == null && validator.isValidInput("requestHeaders in getData", requestHeaders.toString(), "HTTPHeaderValue", requestHeaders.toString().length(), true)) {
			String UUID = UUIDGenerator.nextUUID();
			requestHeaders.putIfAbsent("X-PC-Transaction-ID", UUID);			
			mutableRequest.putHeader("X-PC-Transaction-ID", UUID);
			LOG.info("transaction_id for request headers:" + requestHeaders.get("X-PC-Transaction-ID"));
		}
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, PUT, HEAD ,GET, OPTIONS, DELETE");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers",
				"Content-Type, Access-Control-Allow-Origin, X-Requested-With, Content-Type, Accept, Key, Authorization");
		response.setHeader("Access-Control-All-Headers",
				"Origin, X-Requested-With, Content-Type, Accept, Key, Authorization");
		response.setHeader("X-Frame-Options", "DENY");
		try {
			String request_uri = ValidateString(request.getRequestURI().toString(), "request URI in doFilter", "HTTPURI");
			String request_url = ValidateString(request.getRequestURL().toString(), "request URL in doFilter", "HTTPURL");
			
			if (request.getQueryString() != null
					&& ValidateString(request.getQueryString(), "request QueryString() in doFilter", "HTTPQueryString").contains(CODE + EQUAL)) {
				LOG.info("doFilter: request.getQueryString().contains(code=) ");
				setUserInformation(request, response);
			} else if (request.getQueryString() != null
					&& ValidateString(request.getQueryString(), "request QueryString() in doFilter", "HTTPQueryString").contains(LOGOUT)) {
				response.sendRedirect(
						validateSendRedirect(uaa_url.replaceAll(AUTH_AUTHORIZE, EMPTY) + LOGOUT + QUESTION_MARK + REDIRECT + EQUAL
								+ request_url.replaceAll(request_uri, EMPTY)
								+ SLASH + LOGOFF + QUESTION_MARK + "r="+UUID.randomUUID().toString()));
			} else if (request_uri.contains(LOGOFF)) {
				response.sendRedirect(validateSendRedirect(logout+"?r="+UUID.randomUUID().toString()));
			} else if (request_uri.equalsIgnoreCase(SLASH)
					|| request_uri.contains("/sc/")
					|| request_uri.contains("/sc-test/")
					|| request_uri.contains("/pc-admin-ui/")) {
				Cookie[] cookies = request.getCookies();
				boolean loginFlag = false;
				if (cookies != null) {
					for (Cookie cookie : cookies) {
						if (SC_TOKEN.equals(cookie.getName())) {
							loginFlag = true;
						}
					}
				}
				if (loginFlag) {
					LOG.info("Inside  sc > got the token ");
					if(request.getHeader("Authorization") !=null && checkRoles(request.getHeader("Authorization")) &&
									!request_uri.contains("/pc-admin-ui/") &&!request_uri.contains("/sc-test/") &&
									!request_uri.contains("/userinfo") && !request_uri.contains("/userroles") &&
									!request_uri.contains("/users/authorize"))
                        response.setStatus(403);
                     else
                        chain.doFilter(req, res);
				} else {
					LOG.info("Inside  sc > sc_token == null ");
					if(request_uri.contains("/pc-admin-ui/")) {
						response.sendRedirect(validateSendRedirect(uaa_url + UAA_TOKEN + uaa_client + REDIRECT_URI + request_url.replaceAll(request_uri, EMPTY) + SLASH + UAA_TOKEN_ADMIN_REDIRECT));
					} else {
						if(request_url.contains("sc-test/")){
							response.sendRedirect(validateSendRedirect(uaa_url + UAA_TOKEN + uaa_client + REDIRECT_URI + request_url.replaceAll(request_uri, EMPTY) + SLASH + UAA_TOKEN_SC_REDIRECT));
						} else {
							response.sendRedirect(validateSendRedirect(uaa_url + UAA_TOKEN + uaa_client + REDIRECT_URI + request_url + UAA_TOKEN_SC_REDIRECT));	
						}
					}
				}
			} else {
				LOG.info("Everything else is here ...");
				if(request.getHeader("Authorization") !=null && checkRoles(request.getHeader("Authorization")) &&
								!request_uri.contains("/pc-admin-ui/") && !request_uri.contains("/sc-test/") &&
								!request_uri.contains("/userinfo") && !request_uri.contains("/userroles") && 
								!request_uri.contains("/users/authorize"))
					response.setStatus(403);
				else
                    chain.doFilter(req, res);
			}
		} catch (IntrusionException | ValidationException | EncodingException e) {
			// TODO Auto-generated catch block
			try {
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				// e1.printStackTrace();
				LOG.info("Exception in throw validation exception in doFilter");
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
	}

	private HashMap<String, String> getToken(HttpServletRequest request)
			throws IOException, IntrusionException, ValidationException {
		LOG.info("doFilter: getToken() ");
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		String token = EMPTY;
		HashMap<String, String> mapToken = new HashMap<String, String>();
		String request_uri = ValidateString(request.getRequestURI().toString(), "request URI in getToken", "HTTPURI");
		String request_url = ValidateString(request.getRequestURL().toString(), "request URL in getToken", "HTTPURL");
		try {
			String code = ValidateString(request.getQueryString(), "request QueryString() in getToken", "HTTPQueryString").replace(CODE + EQUAL, EMPTY);
			List<Header> headers = new ArrayList<Header>();
			org.apache.http.HttpEntity entity= null;
			httpClient = HttpClients.createDefault();
			// String authHeader = "Basic " + new
			// String(Base64.encodeBase64((uaa_id + ":" +
			// uaa_secret).getBytes()));
			String authHeader = BASIC_HEADER_NAME
					+ new String(Base64.encodeBase64((uaa_id + ":" + ValidateString(uaa_key, "uaa_key in getToken", "uaaKey")).getBytes(Charset.forName("UTF-8"))));
			headers.add(new BasicHeader("Content-Type", MediaType.APPLICATION_FORM_URLENCODED));
			headers.add(new BasicHeader(AUTH_HEADER_NAME, authHeader));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			if(request_uri.contains("/pc-admin-ui/")){
				entity = new StringEntity(UAA_TOKEN_AUTH + code + UAA_TOKEN_ADMIN_UI + request_url.replaceAll(request_uri, EMPTY) + SLASH + UAA_TOKEN_ADMIN_REDIRECT);
			} else {
				entity = new StringEntity(UAA_TOKEN_AUTH + code + UAA_TOKEN_SC_UI + request_url.replaceAll(request_uri, EMPTY) + SLASH + UAA_TOKEN_SC_REDIRECT);
			}
			HttpPost method = new HttpPost(uaa_token);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			method.setEntity(entity);
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			token = EntityUtils.toString(responseEntity);
			LOG.info("Token = " + token);
			JSONObject objtoken = new JSONObject(token);
			token = objtoken.getString(TOKEN_TYPE) + " " + objtoken.getString(ACCESS_TOKEN);
			mapToken.put(SC_TOKEN, token);
			mapToken.put(SC_REFRESH_TOKEN, objtoken.getString(REFRESH_TOKEN));
			mapToken.put(SC_EXPIRES_IN, String.valueOf(objtoken.getInt(EXPIRES_IN)));
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}
		}
		return mapToken;
	}

	private String getSSOId(String token) throws IOException {
		LOG.info("doFilter: getSSOId() ");
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		String Userinfo = EMPTY;
		try {
			List<Header> headers = new ArrayList<Header>();
			httpClient = HttpClients.createDefault();
			headers.add(new BasicHeader(AUTH_HEADER_NAME, token));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			HttpGet method = new HttpGet(uaa_userInfoUri);
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			httpResponse = httpClient.execute(method);
			HttpEntity responseEntity = httpResponse.getEntity();
			Userinfo = EntityUtils.toString(responseEntity);
			JSONObject objtoken = new JSONObject(Userinfo);
			Userinfo = objtoken.getString(USER_NAME);
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
			if (httpResponse != null) {
				httpResponse.close();
			}
		}
		return Userinfo;
	}

	private void setUserInformation(HttpServletRequest request, HttpServletResponse response)
			throws IOException, IntrusionException, ValidationException, EncodingException {

		if (request != null && request.getSession() != null && request.getRequestURL() != null
				&& request.getQueryString() != null) {
			LOG.info("doFilter: setUserInformation() ");
			HashMap<String, String> mapToken = getToken(request);
			String token = mapToken.get(SC_TOKEN);
			String refresh_token = mapToken.get(SC_REFRESH_TOKEN);
			String expires_in = mapToken.get(SC_EXPIRES_IN);
			String ssoId = getSSOId(token);
			sendToken(request, token);
			request.getSession().setAttribute(SC_TOKEN, token);
			LOG.info("Store value in cookie");
			// set cookie true for httponly and secure
			Cookie ssoCookie=new Cookie(SC_SSO, ssoId);
			/*ssoCookie.setHttpOnly(true);
			ssoCookie.setSecure(true);*/
			response.addCookie(ssoCookie);
			// set cookie true for httponly and secure
            Cookie scExpireInCookie=new Cookie(SC_EXPIRES_IN, expires_in);
            /*scExpireInCookie.setHttpOnly(true);
            scExpireInCookie.setSecure(true);*/
            response.addCookie(scExpireInCookie);
			Cookie token_cookie = new Cookie(SC_TOKEN, token);
			token_cookie.setMaxAge(2 * 60 * 60);
			/*token_cookie.setHttpOnly(true);
			token_cookie.setSecure(true);*/
			response.addCookie(token_cookie);
			token_cookie = new Cookie(SC_REFRESH_TOKEN, "\"" + refresh_token + "\"");
			token_cookie.setMaxAge(2 * 60 * 60);
			/*token_cookie.setHttpOnly(true);
            token_cookie.setSecure(true);*/
			response.addCookie(token_cookie);
			response.setHeader("X-Frame-Options", "DENY");
			LOG.info("Call Redirection method");
			moveForward(request, response, token);
		}

	}

	public void sendToken(HttpServletRequest request, String token) throws IOException {
		LOG.info("doFilter: sendToken() ");
		CloseableHttpClient httpClient = null;
		try {
			List<Header> headers = new ArrayList<Header>();
			httpClient = HttpClients.createDefault();
			headers.add(new BasicHeader("Content-Type", MediaType.APPLICATION_FORM_URLENCODED));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			headers.add(new BasicHeader(AUTH_HEADER_NAME, token));
			org.apache.http.HttpEntity entity = new StringEntity(TOKEN + EQUAL + token);
			LOG.info("doFilter: sendToken() "
					+ request.getRequestURL().toString().replaceAll(request.getRequestURI().toString(), EMPTY)
					+ "/pc-access-control/users/authorize");
			/*HttpPost method = new HttpPost(
					request.getRequestURL().toString().replaceAll(request.getRequestURI().toString(), EMPTY)
							+ "/pc-access-control/users/authorize");*/
			HttpPost method = new HttpPost("https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/pc-access-control/users/authorize");
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			method.setEntity(entity);
			httpClient.execute(method);
			LOG.info("sendToken() End");
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
		}

	}

	public String validateSendRedirect(String url) throws IntrusionException, ValidationException, EncodingException {
		// return validator.getValidInput("validate send redirect", url,
		// "httpResponse", url.length(), true);

		Encoder encoder = new DefaultEncoder(new ArrayList<String>());
		// first canonicalize
		String clean = encoder.canonicalize(url).trim();
		// then url decode
		clean = encoder.decodeFromURL(clean);

		// detect and remove any existent \r\n == %0D%0A == CRLF to prevent HTTP
		// Response Splitting
		int idxR = clean.indexOf('\r');
		int idxN = clean.indexOf('\n');

		if (idxN >= 0 || idxR >= 0) {
			throw new ValidationException("CRLF characters are not allowed",
					"Redirection URL may contain CRLF characters");
		}

		// re-encode again
		return clean;

	}
	
	private void moveForward(HttpServletRequest request, HttpServletResponse response, String token) throws IOException, IntrusionException, ValidationException, EncodingException {
		boolean IsSupplier = false;
			boolean IsSourcing = false;
			boolean IsAdmin = false;
			UserDetailsDto user = userDataSource.getUser(token);
			@SuppressWarnings("unchecked")
			List<UserRolesDto> roles = user.getRoles();
			@SuppressWarnings("unchecked")
  			Collection<GrantedAuthority> credentials = (Collection<GrantedAuthority>) user.getAuthorities();
			String request_uri = ValidateString(request.getRequestURI().toString(), "request URI in moveForward", "HTTPURI");
			String request_url = ValidateString(request.getRequestURL().toString(), "request URL in moveForward", "HTTPURL");
			LOG.info("doFilter: moveForward() URI ----> "+request_uri);
			LOG.info("doFilter: moveForward() URL ---->"+request_url);
			for (GrantedAuthority authority : credentials) {
				if (authority.getAuthority().equalsIgnoreCase("MDM_ADMIN_UI"))
					IsAdmin = true;
			}
			if(roles.size() == 0){
				LOG.info("Rajendra Rajani 1");
				response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString()+ "#/noaccess"));
			} else{
				
				for (UserRolesDto role : roles) {
						if (role.getName().equalsIgnoreCase(SUPPLIER) || role.getName().equalsIgnoreCase(SUPPLIER_ACC_RECE) || role.getName().equalsIgnoreCase(SUPPLIER_ORD_FUL) || role.getName().equalsIgnoreCase(SUPPLIER_SALES)){
							IsSupplier = true;
						}else {
							IsSourcing = true;
						}              
				}
				if (IsSupplier && !IsSourcing)
					if(request_uri.contains("/pc-admin-ui/"))
						response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)).toString()+ "/sc-test/#/noaccess"));	
					else if(user.isTermsAndConditionsAccepted())
							if(checkTask(request, response, token))
								response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString()+ "#/onboarding/supplierHome"));
							else
								response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString()+ "#/myData"));
					else
						response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString()+ "#/terms"));
				else
					if(user.isTermsAndConditionsAccepted())
						if(request_uri.contains("/pc-admin-ui/"))
								if(IsAdmin)
									response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString().replaceAll("code=", EMPTY)
											.replaceAll(ValidateString("request QueryString() in setUserInformation", request.getQueryString(), "HTTPQueryString").replace("code=", EMPTY),	EMPTY)));
								else
									response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)).toString()+ "/sc-test/#/noaccess"));
						else
								response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString().replaceAll("code=", EMPTY)
										.replaceAll(ValidateString("request QueryString() in setUserInformation", request.getQueryString(), "HTTPQueryString").replace("code=", EMPTY),EMPTY)));	
					else
						response.sendRedirect(validateSendRedirect((request_url.replaceAll(request_uri, EMPTY)+ request_uri).toString()+ "#/geterms"));
			}
	}
	
	private Map<String, String> getHeadersInfo(HttpServletRequest request) {

		Map<String, String> map = new HashMap<String, String>();
		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
				String key = (String) headerNames.nextElement();
				String value = request.getHeader(key);
				map.put(key, value);
		}
		return map;
	}
	
	private boolean checkRoles(String token) throws IOException, IntrusionException, ValidationException, EncodingException {
		UserDetailsDto user = userDataSource.getUser(token);
		@SuppressWarnings("unchecked")
		List<UserRolesDto> roles = user.getRoles();			
return false;
//		if(roles.size() == 0)
//			return true;
//		else	
//			return false;
	}
	
	public String ValidateString(String value,String context,String regexName) throws IntrusionException, ValidationException
	{
		return validator.getValidInput(context, value, regexName ,value.length(), true);
	}
	
	public boolean checkTask(HttpServletRequest request, HttpServletResponse response, String token) throws IOException
	{
		LOG.info("doFilter: checkTask() ");
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		try {
			List<Header> headers = new ArrayList<Header>();
			httpClient = HttpClients.createDefault();
			headers.add(new BasicHeader("Content-Type", MediaType.APPLICATION_FORM_URLENCODED));
			headers.add(new BasicHeader("Pragma", "no-cache"));
			headers.add(new BasicHeader(AUTH_HEADER_NAME, token));
			LOG.info("doFilter: sendToken() "
					+ request.getRequestURL().toString().replaceAll(request.getRequestURI().toString(), EMPTY)
					+ "/pc-onboarding-util/v1/getAssignedOnboardingTask/?taskType=INVITE_NEW_SUPPLIER_SELF_SERVE");
			HttpPost method = new HttpPost(
					request.getRequestURL().toString().replaceAll(request.getRequestURI().toString(), EMPTY)
							+ "/pc-onboarding-util/v1/getAssignedOnboardingTask/?taskType=INVITE_NEW_SUPPLIER_SELF_SERVE");
			method.setHeaders(headers.toArray(new Header[headers.size()]));
			httpResponse = httpClient.execute(method);
			LOG.info("checkTask() End" + httpResponse.getStatusLine().getStatusCode());
			if(httpResponse.getStatusLine().getStatusCode() == 200){
				return true;
			}
			return false;		
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
		}
	}
}
