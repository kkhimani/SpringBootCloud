package com.ge.supplierconn.model;

import java.util.UUID;

public class UUIDGenerator {
	public static String nextUUID() {
		return UUID.randomUUID().toString();
	}
}
