
package com.ge.supplierconn;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.google.common.base.Predicates;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import static springfox.documentation.builders.PathSelectors.regex;

@SpringBootApplication
@EnableZuulProxy
@EnableAspectJAutoProxy(proxyTargetClass = true)
@EnableSwagger2
@EnableWebSecurity
public class PcApiGatewayApplication {

	public static void main(String[] args) {
		new SpringApplicationBuilder(PcApiGatewayApplication.class).web(true).run(args);
	}

	@Bean
	public Docket newsApi() {

		return new Docket(DocumentationType.SWAGGER_2).groupName("Supplier").apiInfo(apiInfo()).select()
				.paths(regex("/.*")).paths(Predicates.not(PathSelectors.regex("/error.*"))).build()
				.useDefaultResponseMessages(false);
	}

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("Supplier Connect").description("Supplier Connect Portal")
				// .termsOfServiceUrl(
				// "http://www-03.ibm.com/software/sla/sladb.nsf/sla/bm?Open")
				// .contact("TCS AHD")
				// .license("Apache License Version 2.0")
				// .licenseUrl(
				// "https://github.com/IBM-Bluemix/news-aggregator/blob/master/LICENSE")
				.version("2.0").build();
	}
}
