package com.ge.supplierconn;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URI;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.SpringApplicationContextLoader;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringApplicationContextLoader.class)
@WebAppConfiguration

public class PcApiGatewayApplicationTest {
    
    private static final Logger LOG = LoggerFactory.getLogger(PcApiGatewayApplicationTest.class);

	private MockMvc mvc;

	private static final String SERVICE_NAME = "TEST_SERVICE";

	private static final String SERVICE_URL_FROM_REG = "http://eureka-reg/TEST_SERVICE";

	PcApiGatewayApplication gateway = new PcApiGatewayApplication();

	@Mock
	private LoadBalancerClient mockLoadBalancer = mock(LoadBalancerClient.class);

	@Mock
	ServiceInstance mockServiceInstance = mock(ServiceInstance.class);

	RestTemplate restTemplate = mock(RestTemplate.class);

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(gateway, "loadBalancer", mockLoadBalancer);
		ReflectionTestUtils.setField(restTemplate, "restTemplate", restTemplate);
		mvc = MockMvcBuilders.standaloneSetup(gateway).build();
	}

	@Ignore
	@Test
	public void testGetData_OK() throws Exception {
		java.net.URI uri = new URI(SERVICE_URL_FROM_REG);

		when(mockLoadBalancer.choose(SERVICE_NAME)).thenReturn(mockServiceInstance);
		when(mockServiceInstance.getUri()).thenReturn(uri);
		// when(restTemplate.exchange(Mockito.isA(String.class), HttpMethod.GET,
		// Mockito.isA(HttpEntity.class), String.class)).thenReturn(res) ;
		RequestBuilder builder = MockMvcRequestBuilders.get("/" + SERVICE_NAME);
		ResultActions a = mvc.perform(builder);
		LOG.info(a.toString());

	}

}
